Oct0pus Beta 1.0.8
-----------------
Oct0pus is a multi-clipboard manager.

-----------------
What is New?
-----------------<
[1.0.4]
Key ESC bug problem solved.
Always on top added.
Start with Windows configuration option added.
[1.0.5]
Too long strings bug solved.
[1.0.6]
Unloader module added.
Auto-Unload previnstance option added.
[1.0.7]
User friendly installer mode (very easy to update).
Setup Loader added.
Start with windows check to able/unable option.
User selected invocation keys.
[1.0.8]
Static Clipboard option added.
[1.0.10]
Static Clipboard bug solved.
Delete Clipboard bu solved.

-----------------
What it does
-----------------
In brief, Oct0pus uses windows API in order to manage 8 clipboards.

-----------------
Installation
-----------------
Just simply run Install-Octopus.exe to install.

-----------------
Usage
-----------------
Press SHIFT + CTRL (or whatever you choose) on your keyboard to access the clipboard management.
Press ESC to close.
To Setup configuration run Setup.exe.

-----------------
Credits
-----------------
This software is developed entirely by mRt.

-----------------
Contact
-----------------
martin.cerdeira@speedy.com.ar
